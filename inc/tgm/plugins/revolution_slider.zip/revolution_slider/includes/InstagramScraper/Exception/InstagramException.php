<?php

namespace InstagramScraper\Exception;

class InstagramException extends \Exception
{
}